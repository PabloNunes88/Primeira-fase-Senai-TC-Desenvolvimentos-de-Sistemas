/*Calculadora de média escolar: Faça um programa que solicite ao usuário as notas de três provas e, em seguida, calcule e exiba a média. Se a média for maior ou igual a 7, exiba "Aprovado"; senão, exiba "Reprovado"*/

let notaUm
let notaDois
let notaTres
let media

notaUm=Number(prompt("Digite a primeira nota: "))
notaDois=Number(prompt("Digite a segunda nota: "))
notaTres=Number(prompt("Digite a terceira nota: "))

media=(notaUm+notaDois+notaTres)/3
if(media>=7){
    alert("Aprovado")
}else{
    alert("Reprovado")
}
