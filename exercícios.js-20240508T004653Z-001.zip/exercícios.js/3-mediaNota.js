/*Criar um programa que realize o cálculo de uma média da faculdade. A média é composta por três notas: Atividade Individual (peso 1), Seminário em Equipe (peso 1), Projeto final (peso 3). O usuário deve digitar as três notas e a média deve ser mostrada na tela.*/

let atividadePeso1
let seminarioPeso1
let projetoPeso3
let media=0

atividadePeso1=Number(prompt("Digite a nota da atividade individual: "))
seminarioPeso1=Number(prompt("Digite a nota do seminário em equipe:  " ))
projetoPeso3=Number(prompt("Digite a nota do projeto final: "))

alert("A média é: "+(projetoPeso3*3+atividadePeso1+seminarioPeso1)/5)

