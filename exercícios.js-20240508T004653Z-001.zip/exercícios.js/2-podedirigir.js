/* Simulador de trânsito: Crie um programa que pergunte a idade do usuário e, se ele tiver idade suficiente para dirigir (por exemplo, 18 anos), exiba "Você pode dirigir"; caso contrário, exiba "Você ainda não pode dirigir".*/

let idade

idade=Number(prompt("Digite sua idade: "))
if(idade>=18){
    alert("Você pode dirigir: ")
}else{
    alert("Você ainda não pode dirigir: ")
}
