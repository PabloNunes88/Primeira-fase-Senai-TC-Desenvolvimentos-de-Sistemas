/*6) Criar um programa que calcule o IMC, no qual o usuário deve digitar o seu peso e altura, realizar o cálculo (peso / altura * altura) e mostrar o resultado na tela, com 3 casas depois da vírgula. */

let pesoPessoa
let alturaPessoa
let somaTotal= 0 

pesoPessoa= Number(prompt("Digite seu peso: "))
alturaPessoa=Number(prompt("Digite sua altura ex: 2.10 : "))
somaTotal=(pesoPessoa/alturaPessoa **2)
somaTotal=somaTotal.toFixed(3)
alert("Seu IMC é : "+ somaTotal)