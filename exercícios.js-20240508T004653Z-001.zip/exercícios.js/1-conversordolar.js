/* Conversor de moedas: Escreva um programa que converta uma quantidade de dólares em reais. Se o valor do dólar estiver acima de 5 reais, exiba uma mensagem informando que está caro, senão exiba uma mensagem de que está barato.*/

let dolar
let valorDolar
let real
let soma= 0

dolar=Number(prompt("Qual valor do dolar hoje: "))
real=Number(prompt("Quantos dólares vamos converter: "))
soma=(dolar*real)
if(dolar>5.00){
    alert("Está caro: ")
}else{
    alert("Está barato os "+real+" dolar covertido em reais é R$" + soma+"")
}

