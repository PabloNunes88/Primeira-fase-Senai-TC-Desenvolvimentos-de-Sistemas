/*Faça um programa no qual o usuário digite dois números
 e mostre na tela a multiplicação desses números.*/

 let numeroUm
 let numeroDois
 
 numeroUm= Number(prompt("Digite um número: "))
 numeroDois= Number(prompt("Digite outro número: "))

 alert(numeroUm * numeroDois)
