/* Crie um programa que peça os dados de um cliente: Nome, idade, 
nacionalidade, endereço. Após digitados os dados, mostrar na tela a seguinte
 mensagem "Cliente [Nome], com [idade] anos, [nacionalidade], reside no endereço
  [endereço]". Exemplo: Cliente Lucas, com 29 anos, brasileiro, reside no endereço
   Rua Victor Meirelles, 281, Centro, Florianópolis.*/

   let nomePessoa
   let idadePessoa
   let nacionalidade
   let enderecoPessoa
   
   nomePessoa= prompt("Digite seu nome: ")  
   idadePessoa = Number(prompt("Digite sua idade: "))
   nacionalidade= prompt("Digite sua nacionalidade: ")
   enderecoPessoa= prompt("Digite seu endereço: ") 

alert(" Cliente " +nomePessoa+  " tem " + idadePessoa+" anos "+nacionalidade+" reside no endereço "+enderecoPessoa)