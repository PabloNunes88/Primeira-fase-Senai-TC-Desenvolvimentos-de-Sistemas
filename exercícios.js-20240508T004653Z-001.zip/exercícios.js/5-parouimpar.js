/*Verificador de número par ou ímpar: Faça um programa que peça ao usuário para inserir um número e determine se par ou ímpar.*/

let numero

numero=Number(prompt("Digite um número: "))

if(numero%2 == 0){
    alert("Número par: ")
}else{
    alert("Número impar: ")
}