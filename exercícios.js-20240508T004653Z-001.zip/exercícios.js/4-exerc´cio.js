/*Programar a conversão de uma temperatura digitada pelo usuário
 em graus Celsius para Fahrenheit. Mostrar o resultado na tela. */

 let grausCelsius
 let fahrenheit
 let soma

 grausCelsius=Number(prompt("Digite a temperatura: "))
 fahrenheit=( grausCelsius * 1.8)+ 32
alert("Os graus em fahrenheit é :"+ fahrenheit)