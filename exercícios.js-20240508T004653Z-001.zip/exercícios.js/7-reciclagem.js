/*Em uma fábrica de reciclagem de materiais, cada 10kg de plástico rendem R$2,00 cada 30kg de papel rendem R$3,00 e cada 50kg de metal rendem R$5,00. Perguntar ao usuário a quantidade (kg) de cada material que deseja entregar na fábrica e mostrar o total que receberá em reais. */

let plastico
let papel
let metal
let soma1
let soma2
let soma3
let somaTotal= 0

plastico=Number(prompt("Quantos kilos de plástico são: "))
papel=Number(prompt("Quantos kilos de papel são: "))
metal=Number(prompt("Quantos kilos de metal são: "))

soma1= (plastico* 0.20)
soma2= (papel* 0.10)
soma3= (metal * 0.10)
somaTotal=( soma1+ soma2 + soma3)
somaTotal= somaTotal.toFixed(2)
alert("O total dos materiais reciclados foi R$"+ somaTotal+ " centavos.")