/*Verificador de idade para desconto no cinema: Escreva um programa que pergunte a idade do usuário e, se ele tiver menos de 12 anos, conceda um desconto de 50% no ingresso do cinema; se ele tiver entre 12 e 18 anos, conceda um desconto de 25%; caso contrário, não conceda nenhum desconto.*/

let idade

idade=Number(prompt("Digite sua idade: "))

if(idade<=11){
    alert("Voçê ganhou 50% de desconto no cinema: ")
}else if(idade<=18){
    alert("Você tem direito de 25% de desconto no cinema: ")
}else{
    alert("Você não tem direito a descontos no cinema: ")
}



