/* Seu sonho é construir uma piscina. Para cada metro quadrado, são necessários 120 azulejos. O cálculo de área em metros quadrados, é feito multiplicando a largura pelo comprimento. Digitar os valores (em metros) da largura e comprimento que deseja a piscina. Mostrar na tela a quantidade de azulejos que devem ser comprados e o valor total a ser pago, sendo que uma caixa de azulejo com 60 unidades custa R$45,50.*/

let metro= 91
let larguraPiscina
let comprimentoPiscina
let total
let areaTotal

larguraPiscina=Number(prompt("Digite a largura da piscina: "))
comprimentoPiscina=Number(prompt("Digite o comprimento da piscina: "))
alert("o valor total é R$"+larguraPiscina*comprimentoPiscina*metro+"\nÁrea total em metros quadrados é "+larguraPiscina*comprimentoPiscina+"\n e total de azulejos é:"+larguraPiscina*comprimentoPiscina*120)

