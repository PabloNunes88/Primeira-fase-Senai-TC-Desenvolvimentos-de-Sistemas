/*Uma cidade pretende apurar os votos de sua eleição. Faça um
 programa para ler o número total de eleitores. Em seguida o número de votos
  do candidato X, o número de votos do candidato Y, total de votos brancos e total de votos 
  nulos (a soma desses quatro, deve ser igual ao total de eleitores). Calcular e escrever o percentual 
  que cada um representa em relação ao total de eleitores.*/

  let candidatoX
  let candidatoY
  let totalVotos
  let votosBrancos
  let votosNulos
  let percVotosX, percVotosY, percVotosBrancos, percVotosNulos

  totalVotos= Number(prompt("Digite o total de eleitores: "))
  candidatoX= Number(prompt("Digite os votos do candidato X: "))
  candidatoY= Number(prompt("Digite os votos do candidato Y: "))
  votosBrancos= Number(prompt("Votos em brancos: "))
  votosNulos= Number(prompt("Votos nulos: "))
 
    percVotosX = (candidatoX / totalVotos) *100
    percVotosY = (candidatoY/ totalVotos) *100
    percVotosBrancos = (votosBrancos / totalVotos) *100
    percVotosNulos = (votosNulos / totalVotos) *100

    alert("\nA percentagem de votos do candidatoX é :"+ percVotosX +"%" +" \nA porcentagem de votos do candidatoY é "+ percVotosY+"%" + "\n Porcentagem de votos brancos é "+ percVotosBrancos+"%" +"\n Porcentagem de votos nulos é "+ percVotosNulos+"%")


