/* Você é um amante da natureza e adora fazer trilhas. Criar um programa que calcule a velocidade média das trilhas que você realiza. Para isso, devem ser digitados os dados de distância percorrida (quilômetros) e tempo que a trilha durou (horas). Fazer então o cálculo da velocidade média e mostrar na tela a mensagem "Sua média de velocidade durante essa trilha foi de X km/h", sendo X a velocidade.*/

let distanciaKm
let horasTrilha
let soma= 0

distanciaKm= Number(prompt("Distância percorrida: "))
horasTrilha= Number(prompt("Quanto tempo demorou a trilha: "))
soma= (distanciaKm/horasTrilha)
alert("Sua média de velocidade durante a trilha foi de "+soma+ "Km/h, sendo  a velocidade: " )

