/*Desenvolva uma programação que peça ao usuário para digitar o ano
 do seu nascimento no formato (YYYY) e o ano atual também no formato (YYYY).
  Em seguida mostre na tela qual a idade do usuário em anos, em meses,
   em dias e em semanas.*/

   let anoNascimento
   let anoAtual
   let idadeAtual
   let semanas
   let meses
   let dias


   anoNascimento= Number(prompt("Digite seu ano de nascimento no formato (YYYY): "))
   anoAtual=Number(prompt("Digite ano atual em formato (YYYY): "))
   idadeAtual=(anoAtual-anoNascimento)
   meses=(idadeAtual * 12)
   dias= (idadeAtual * 365)
   semanas= (dias / 7)
   alert("Sua idade é "+idadeAtual+ " anos " +meses+ " meses "+semanas+ " semanas e "+dias+ " dias:")